============================
Supported Embedded Platforms
============================

For information on how to add support for another embedded system, see the
:doc:`board support </advanced/devguide>` section.

.. toctree::
    :maxdepth: 1

    ford
    blueboard
    max32
    crosschasm-c5
