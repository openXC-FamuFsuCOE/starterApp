#include "interface/network.h"

void openxc::interface::network::initialize(NetworkDevice* uart) { }

void openxc::interface::network::processSendQueue(NetworkDevice* device) { }

void openxc::interface::network::read(NetworkDevice* device, openxc::util::bytebuffer::IncomingMessageCallback callback) { }
