#include "platform/platform.h"

void openxc::platform::initialize() {
}
