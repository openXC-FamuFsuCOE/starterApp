#ifndef __POWER_SPY_H__
#define __POWER_SPY_H__

#include "power.h"

namespace openxc {
namespace power {
namespace spy {

int getWatchdogTime();

} // namespace spy
} // namespace power
} // namespace openxc

#endif
