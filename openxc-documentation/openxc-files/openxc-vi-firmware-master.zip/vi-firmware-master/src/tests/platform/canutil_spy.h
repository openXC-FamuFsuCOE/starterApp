#ifndef __CANUTIL_SPY_H__
#define __CANUTIL_SPY_H__

#include "can/canutil.h"

namespace openxc {
namespace can {
namespace spy {

bool acceptanceFiltersUpdated();

} // spy
} // can
} // openxc

#endif // __CANUTIL_SPY_H__
