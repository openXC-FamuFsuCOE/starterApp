#include "can/canwrite.h"

bool openxc::can::write::sendMessage(const CanBus* bus, const CanMessage* request) {
    return false;
}
