#ifndef __DEVICE_ID_COMMAND_H__
#define __DEVICE_ID_COMMAND_H__

namespace openxc {
namespace commands {

bool handleDeviceIdCommmand();

} // namespace commands
} // namespace openxc

#endif // __DEVICE_ID_COMMAND_H__
