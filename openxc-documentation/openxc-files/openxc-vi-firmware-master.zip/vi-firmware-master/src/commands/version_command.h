#ifndef __VERSION_COMMAND_H__
#define __VERSION_COMMAND_H__

namespace openxc {
namespace commands {

bool handleVersionCommand();

} // namespace commands
} // namespace openxc

#endif // __VERSION_COMMAND_H__
