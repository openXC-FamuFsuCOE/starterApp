==========
Data Sinks
==========

.. automodule:: openxc.sinks.base
    :members:
    :undoc-members:

.. automodule:: openxc.sinks.notifier
    :members:
    :undoc-members:

.. automodule:: openxc.sinks.queued
    :members:
    :undoc-members:

.. automodule:: openxc.sinks.recorder
    :members:
    :undoc-members:

.. automodule:: openxc.sinks.uploader
    :members:
    :undoc-members:
