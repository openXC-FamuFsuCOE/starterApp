package com.openxc;

public class NoValueException extends Exception {
    private static final long serialVersionUID = -5048469152473546972L;
}
