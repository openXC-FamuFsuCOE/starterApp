/**
 * Contains classes that generate new vehicle measurements (from USB, Serial, a
 * trace file, etc.).
 */
package com.openxc.sources;
