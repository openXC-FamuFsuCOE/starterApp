/**
 * Contains a vehicle data source that connects to a vehicle interface via a network.
 */
package com.openxc.interfaces.network;
