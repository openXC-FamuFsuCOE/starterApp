/**
 * All possible types of measurements that can be obtained from a vehicle.
 */
package com.openxc.measurements;
