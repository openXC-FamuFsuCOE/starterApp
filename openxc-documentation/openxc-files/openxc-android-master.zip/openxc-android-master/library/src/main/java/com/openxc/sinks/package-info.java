/**
 * Contains classes that can perform some function on all vehicle measurements
 * received.
 */
package com.openxc.sinks;
